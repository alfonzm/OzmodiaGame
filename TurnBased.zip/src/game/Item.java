package game;

public class Item {

	public static enum itemType{
		armor,weapon,consumable;
	}
	
	private String name;
	private int value;
	private itemType type;
	
	public Item(String name, int value, itemType type){
		setName(name);
		setValue(value);
		setType(type);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public itemType getType() {
		return type;
	}
	public void setType(itemType type) {
		this.type = type;
	}
}

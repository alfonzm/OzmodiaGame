package game;

import java.util.Random;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

public class Play extends BasicGameState{
	public String mouse = "";
	public String text = "";
	public String text2 = "";
	public String floor = "";
	
	int turnDelay;
	
	Image battlemap;
	Image attackButton;
	Image itemsButton;
	Image cursor;
	Image skillsButton;
	Image infoButton;
	Image runButton;
	Image menuWindow;
	Image knightSprite; //------------------------------------------Knight Sprite
	Image mob1;
	Image shopOpen;
	Image shopClose;
	Image healthBar;
	Image defeat, victory;
	Image next;
	
	Monster monster;
	Player player;
	Player playerTemp;
	int playerHP, monsterHP;
	boolean playerIsAlive, monsterIsAlive;
	
	boolean allowBuy;
	boolean battleEnd;
	boolean hoverAttack;
	boolean hoverRun;
	boolean hoverItems;
	boolean hoverSkills;
	boolean paused;
	boolean incLife;
	float posX = 200.0f; 
	float posY = 252.0f;
	
//	public player playerObj;
	
	
	public Play(int state){
	}
	
	public void init(GameContainer gc, StateBasedGame sbg) throws SlickException{
		battlemap = new Image("res/playBg.png");
		cursor = new Image("res/cursor.png");  //cursorImg
		attackButton = new Image("res/AttackButton.png"); //attackButtonImg
		itemsButton = new Image("res/itemsButton-2.png");
		skillsButton = new Image("res/skillsButton.png");
		runButton = new Image("res/runButton.png");
		menuWindow = new Image("res/Pause.png");
		shopOpen = new Image("res/shopButton.png");
		shopClose = new Image("res/unclickableShopeButton.png");
		healthBar = new Image("res/HealthBar.png");
		
		knightSprite = new Image("res/KnightSprite.png");
		mob1 = new Image("res/mob1.png");
		
		victory = new Image("res/victory.png");
		defeat= new Image("res/defeat.png");
		next = new Image("res/next.png");
		
		player = Menu.playerChar;
		playerHP = player.getHealth();
		
		monster = new Monster(player.getLevel(), 100, 50, 5, 5, 5, mob1, "Mob");
		monsterHP = monster.getHealth();
		
		playerIsAlive = true;
		monsterIsAlive = true;
		
		turnDelay = 1000;
	}
	
	public void render(GameContainer gc, StateBasedGame sbg, Graphics g) throws SlickException{
		battlemap.draw(0,0);
//		g.drawString(mouse,50,200);
		attackButton.draw(55,370);
		itemsButton.draw(55, 420);
		skillsButton.draw(200,370);
		runButton.draw(200,420);
		
		// health bar
		g.setColor(Color.red);
		
		if(playerIsAlive)
			g.fillRect(38, 30, ((float)playerHP/(float)player.getHealth()) * 250f, 33);
		
		// monster health bar
		if(monsterIsAlive)
			g.fillRect(355, 30, ((float)monsterHP/(float)monster.getHealth()) * 250f, 33);
		
		g.setColor(Color.white);
		healthBar.draw(10,5);
		
		g.drawString(text, 365, 363);
		g.drawString(text2, 365, 383);
		
		g.drawString(""+player.getLevel(), 311, 25);
		knightSprite.draw(100,220);
		monster.sprite.draw(400,100);
			
		
		if(hoverAttack == true){
			cursor.draw(40,370);
		}
		if(hoverItems == true){
			cursor.draw(40,423);
		}
		if(hoverSkills == true){
			cursor.draw(185,370);
		}
		if(hoverRun == true){
			cursor.draw(185,423);
		}
		
		
		if(allowBuy == true){
			shopOpen.draw(360,420);
		}
		
		
		if(paused==true){
			menuWindow.draw(200,50);
			g.drawString("Resume (R)", 260,240);
			g.drawString("Main Menu (M)", 260,200);
			g.drawString("Quit (Q)", 260, 160);

			if(paused==false){
				g.clear();
			}
		}
		
		if(!playerIsAlive || !monsterIsAlive){
			if(!playerIsAlive){
				g.drawImage(defeat, gc.getWidth()/2 - defeat.getWidth()/2, 103);
			}
			else if(!monsterIsAlive){
				g.drawImage(victory, gc.getWidth()/2 - victory.getWidth()/2, 103);
			}
			text = ""; text2 = "";
			g.drawImage(next, 18, gc.getHeight()-124);
		}
	}
	
	public void update(GameContainer gc, StateBasedGame sbg, int delta) throws SlickException{
		Input input = gc.getInput();
		float posX = Mouse.getX();
		float posY = Mouse.getY();
		floor = "10";
		float y = gc.getHeight() - posY;
		mouse = "Xpos = "+posX+"  Ypos = "+posY;
		hoverAttack = false;
		hoverItems = false;
		hoverSkills = false;
		hoverItems = false;
		hoverRun = false;
		battleEnd = false;
		
		int counter = 0;
		
		if(playerIsAlive && monsterIsAlive){
			// ATTACK BUTTON
			if((posX > 24 && posX < 125) && (posY > 72) && posY < 125){
				if(paused == false)
				hoverAttack = true;
				if(input.isMousePressed(0) && !paused && (monsterIsAlive && playerIsAlive)){

					int damage = attack(player.getStr(), player.equippedItems[0]);
					int damage2 = attack(monster.getStr(), 0);
					if(player.getDex() > monster.getDex()){ // player attacks first					
						monsterHP -= damage;
						monsterIsAlive = isAlive(monsterHP);
						text = monster.getName() + " received " + damage + " damage!";
						
						counter+=delta;
						if(counter < turnDelay){
							playerHP -= damage2;
							playerIsAlive = isAlive(playerHP);
							text2 = player.getName() + " received " + damage2 + " damage!";	
						}
						
					}
					else{ // monster attacks first
						playerHP -= damage2;
						playerIsAlive = isAlive(playerHP);
						text = player.getName() + " received " + damage2 + " damage!";
						counter+=delta;
						if(counter < turnDelay){
							monsterHP -= damage;
							monsterIsAlive = isAlive(monsterHP);
							text2 = monster.getName() + " received " + damage2 + " damage!";
						}					
					}
				}
			}
			// ITEM BUTTON
			else if((posX > 24 && posX < 111) && (posY > 20) && posY < 111){
				if(paused == false)
				hoverItems = true;
				if(input.isMousePressed(0)){
					System.out.println("item");
				}
			}
			// SKILLS BUTTON
			else if((posX > 200 && posX < 340) && (posY > 72) && posY < 112){
				if(paused == false)
				hoverSkills = true;
				if(input.isMousePressed(0)){
					System.out.println("SKills");
				}
				
			}
			// RUN BUTTON
			else if((posX > 200 && posX < 234) && (posY > 20) && posY < 62){
				if(paused == false)
				hoverRun = true;
			}
		}
		// NEXT (END BATTLE)
		else{
			if( (posX > 18 && posX < 18 + next.getWidth()) && (posY > 16 && posY < 125)){

				if(input.isMousePressed(0)){
					sbg.enterState(2);
					Menu.playerChar.setLevel(Menu.playerChar.getLevel()+1);
					this.init(gc, sbg);
				}
			}
				
		}
			
				//when the menu is up
				if(input.isKeyDown(Input.KEY_ESCAPE)){
					paused = true;
				}
				
				if(paused == true){
					if(input.isKeyDown(Input.KEY_R)){
						paused = false;
					}
					if(input.isKeyDown(Input.KEY_M)){
						sbg.enterState(0);
						paused = false;
					}
					if(input.isKeyDown(Input.KEY_Q)){
						System.exit(0);
					}
				}
		
	}
	
	public boolean isAlive(int health){
		if(health <= 0){
			return false;
		}
		else
			return true;
	}
	
	public int getID(){
		return 1;
	}
	
	public int attack(int str,int wepId){//attack method used for both player and monster. Set wepId to 0 if no weapon
        Random rand = new Random();
        return str + rand.nextInt(10) + Menu.itemList.get(wepId).getValue();
}

}

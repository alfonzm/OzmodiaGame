package game;

import org.newdawn.slick.*;

public class Character {
	
	boolean isAlive;
	int hp;
	float xpos,ypos;
	
		public Character() throws SlickException{
		}
}

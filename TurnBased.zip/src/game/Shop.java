package game;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

public class Shop extends BasicGameState{
	

	public String mouse = "";
	Image shopBg;
	float posX = 300.0f; 
	float posY = 300.0f;
	int x,y;
	
	public Shop(int state) {
	}

	@Override
	public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
		shopBg = new Image("res/shopState.png");
	}

	@Override
	public void render(GameContainer gc, StateBasedGame sbg, Graphics g) throws SlickException {
		shopBg.draw(0,0);
		g.drawString(mouse,50,200);
	}

	@Override
	public void update(GameContainer gc, StateBasedGame sbg, int delta) throws SlickException {
		float posX = Mouse.getX();
		float posY = Mouse.getY();

		posY = gc.getHeight() - posY;
		mouse = "Xpos = "+posX+"  Ypos = "+posY;
		
		if((posX > 27 && posX < 158) && (posY > 416) && posY < 472){ 
			if(Mouse.isButtonDown(0)){
				sbg.enterState(2);
				System.out.println("sdfsfsd");
			}
		}
	}

	@Override
	public int getID() {
		
		return 3;
	}

}

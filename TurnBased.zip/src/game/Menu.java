package game;
import java.sql.*;
import java.util.ArrayList;


import game.Item.itemType;
import game.Spell.spellEffect;
import game.Spell.spellTarget;
import game.Spell.spellType;


import org.lwjgl.input.Mouse;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

public class Menu extends BasicGameState{

	static Connection con = null;
	static Statement st = null;
	static ResultSet rs = null;
	
	public String mouse = "";
	boolean hoverPlay; 
	boolean hoverExit;
	Image playNow;
	Image playNowHover;
	Image exit;
	Image exitNowHover;
	Image backGroundImage;
	Image menuBorder;
	public static Player playerChar;
	public static ArrayList<Spell> skillList;
	public static ArrayList<Item> itemList;
	
	
	public Menu(int state){
	}
	
	public void init(GameContainer gc, StateBasedGame sbg) throws SlickException{
		playNow = new Image("res/txt.png");
		exit = new Image("res/exittxt.png");
		backGroundImage = new Image("res/menuBg.png");
		playNowHover = new Image("res/newtxt.png");
		exitNowHover = new Image("res/exittxtHover.png");
		menuBorder = new Image("res/menuBoarder.png");
		
		skillList = new ArrayList<Spell>();
		itemList = new ArrayList<Item>();
		
		skillList.add(new Spell("Fireball",10,spellType.damage,spellTarget.enemy,spellEffect.burn));
		skillList.add(new Spell("Lightning Bolt",10,spellType.damage,spellTarget.enemy,spellEffect.shock));
		skillList.add(new Spell("Ice Spear",10,spellType.damage,spellTarget.enemy,spellEffect.freeze));
		skillList.add(new Spell("Poison Sting",10,spellType.damage,spellTarget.enemy,spellEffect.poison));
		skillList.add(new Spell("Impact",10,spellType.damage,spellTarget.enemy,spellEffect.noEffect));
		skillList.add(new Spell("Might",10,spellType.buff,spellTarget.self,spellEffect.buffStr));
		skillList.add(new Spell("Swiftness",10,spellType.buff,spellTarget.self,spellEffect.buffDex));
		skillList.add(new Spell("Clarity",10,spellType.buff,spellTarget.self,spellEffect.buffInt));
		itemList.add(new Item("Bronze Sword",10,itemType.weapon));
		itemList.add(new Item("Bronze Helm",10,itemType.armor));
		itemList.add(new Item("Bronze Shield",10,itemType.armor));
		itemList.add(new Item("Bronze Armor",10,itemType.armor));
		itemList.add(new Item("Bronze Greaves",10,itemType.armor));
		itemList.add(new Item("Silver Sword",10,itemType.weapon));
		itemList.add(new Item("Silver Helm",10,itemType.armor));
		itemList.add(new Item("Silver Shield",10,itemType.armor));
		itemList.add(new Item("Silver Armor",10,itemType.armor));
		itemList.add(new Item("Silver Greaves",10,itemType.armor));
		itemList.add(new Item("Gold Sword",10,itemType.weapon));
		itemList.add(new Item("Gold Helm",10,itemType.armor));
		itemList.add(new Item("Gold Shield",10,itemType.armor));
		itemList.add(new Item("Gold Armor",10,itemType.armor));
		itemList.add(new Item("Gold Greaves",10,itemType.armor));
		itemList.add(new Item("Health Potion",50,itemType.consumable));
		itemList.add(new Item("Mana Potion",50,itemType.consumable));
		itemList.add(new Item("Elixir",25,itemType.consumable));
		
		String username = "";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "");
            st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM `ozmodia`.`users` WHERE user_ID=15;");

			rs.next();
			username = rs.getString(2);
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		playerChar= new Player(1,100,100,10,10,10,new boolean[skillList.size()],new int[itemList.size()],1000,new int[5], username);
	}
	
	public void render(GameContainer gc, StateBasedGame sbg, Graphics g) throws SlickException{
		g.drawString("Astral",490,50);
		backGroundImage.draw(0,0);
		menuBorder.draw(0,0);
		playNow.draw(285, 200);
		exit.draw(285, 280);
//		g.drawString(mouse,50,50);
		
		if(hoverPlay == true){
			playNowHover.draw(285,200);
		}
		if(hoverExit == true){
			exitNowHover.draw(285, 280);
		}
	}
	
	public void update(GameContainer gc, StateBasedGame sbg, int delta) throws SlickException{
		float posX = Mouse.getX();
		float posY = Mouse.getY();
		mouse = "Xpos = "+posX+"  Ypos = "+posY;
		hoverPlay = false;
		hoverExit = false;
		
		if((posX > 283 && posX < 358) && (posY > 252) && posY < 280){ //hoverPlayButton
			
			hoverPlay = true;
			
			if(Mouse.isButtonDown(0)){
				sbg.enterState(2);
			}
		}
		
		
		if((posX > 290 && posX < 349) && (posY > 170) && posY < 200){//hoverExitButton
			
			hoverExit = true;
			
			if(Mouse.isButtonDown(0)){
				System.exit(0);
			}
		}
	}
	
	
	public int getID(){
		return 0;
	}
	
}
